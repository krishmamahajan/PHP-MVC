<?php
 include_once("controller/control.php");
 include_once("model/Model.php");
 include_once("view/View.php");


$model = new Model();


$controller = new Controller($model);

$view = new View($model);

echo $view->show();



?>